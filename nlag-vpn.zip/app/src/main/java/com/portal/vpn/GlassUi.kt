package com.portal.vpn

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

// ───────────────────────── Палитра ─────────────────────────

@Immutable
data class GlassColors(
    val dark: Boolean,
    val text: Color,
    val dim: Color,
    val glassTop: Color,
    val glassBottom: Color,
    val rimBright: Color,
    val rimDim: Color,
    val accent: Color,
    val good: Color,
    val goodStrong: Color,
    val bad: Color,
    val bgTop: Color,
    val bgBottom: Color,
    val blobs: List<Color>,
    val track: Color,
    val scrim: Color,
)

val LightGlass = GlassColors(
    dark = false,
    text = Color(0xFF0E1726), dim = Color(0xFF6B7588),
    glassTop = Color.White.copy(alpha = 0.70f), glassBottom = Color.White.copy(alpha = 0.34f),
    rimBright = Color.White.copy(alpha = 0.95f), rimDim = Color.White.copy(alpha = 0.35f),
    accent = Color(0xFF2F6BFF), good = Color(0xFF2FD38C), goodStrong = Color(0xFF12A86B),
    bad = Color(0xFFFF5A5F),
    bgTop = Color(0xFFE6EEFF), bgBottom = Color(0xFFF5EEFF),
    blobs = listOf(Color(0xFF7CB0FF), Color(0xFFB69CFF), Color(0xFF7DE8D2), Color(0xFFFFB5CB)),
    track = Color(0x1A0E1726), scrim = Color(0x66000000),
)

val DarkGlass = GlassColors(
    dark = true,
    text = Color.White.copy(alpha = 0.95f), dim = Color(0xFF9AA4B8),
    glassTop = Color.White.copy(alpha = 0.17f), glassBottom = Color.White.copy(alpha = 0.06f),
    rimBright = Color.White.copy(alpha = 0.50f), rimDim = Color.White.copy(alpha = 0.10f),
    accent = Color(0xFF74A5FF), good = Color(0xFF34D399), goodStrong = Color(0xFF5BF0B5),
    bad = Color(0xFFFF7A7F),
    bgTop = Color(0xFF070B16), bgBottom = Color(0xFF140F2E),
    blobs = listOf(Color(0xFF2B59FF), Color(0xFF7A3CF0), Color(0xFF0DB5A5), Color(0xFFD13F86)),
    track = Color.White.copy(alpha = 0.12f), scrim = Color(0x99000000),
)

val LocalGlass = staticCompositionLocalOf { LightGlass }
val LocalHapticsOn = compositionLocalOf { true }

// ───────────────────────── Фон ─────────────────────────

@Composable
fun AuroraBackground(connected: Boolean, glow: Float, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26000, easing = LinearEasing)),
        label = "p",
    )
    val k by animateFloatAsState(if (connected) 1f else 0f, tween(1400), label = "k")
    Canvas(modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(g.bgTop, g.bgBottom)))
        val w = size.width
        val h = size.height
        val ang = p * 2f * PI.toFloat()
        g.blobs.forEachIndexed { i, base ->
            val c = if (i < 3) lerp(base, g.good, k * 0.75f) else base
            val phase = ang + i * 1.7f
            val cx = w * (0.5f + 0.38f * sin(phase + i))
            val cy = h * (0.5f + 0.36f * cos(phase * 0.8f + i * 2f))
            val r = max(w, h) * (0.40f + 0.06f * i)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(c.copy(alpha = 0.60f * glow), Color.Transparent),
                    center = Offset(cx, cy), radius = r,
                ),
                radius = r, center = Offset(cx, cy),
            )
        }
    }
}

// ───────────────────────── Стекло ─────────────────────────

@Composable
fun Modifier.glass(
    shape: Shape,
    tint: Color = Color.Transparent,
    elevation: Dp = 10.dp,
    strength: Float = 1f,
): Modifier {
    val g = LocalGlass.current
    val top = g.glassTop.copy(alpha = (g.glassTop.alpha * strength).coerceAtMost(1f))
    val bottom = g.glassBottom.copy(alpha = (g.glassBottom.alpha * strength).coerceAtMost(1f))
    val sh = Color.Black.copy(alpha = if (g.dark) 0.45f else 0.12f)
    val spec = Color.White.copy(alpha = if (g.dark) 0.10f else 0.35f)
    return this
        .shadow(elevation, shape, ambientColor = sh, spotColor = sh)
        .clip(shape)
        .background(Brush.verticalGradient(listOf(top, bottom)))
        .background(tint)
        .drawBehind {
            drawRect(Brush.verticalGradient(listOf(spec, Color.Transparent), endY = size.height * 0.45f))
        }
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(g.rimBright, g.rimDim, g.rimBright.copy(alpha = g.rimBright.alpha * 0.55f)),
            ),
            shape,
        )
}

@Composable
fun Modifier.bounceClick(enabled: Boolean = true, scaleTo: Float = 0.9f, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) scaleTo else 1f,
        spring(dampingRatio = 0.4f, stiffness = 480f),
        label = "bounce",
    )
    val haptic = LocalHapticFeedback.current
    val hOn = LocalHapticsOn.current
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled) {
            if (hOn) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

// ───────────────────────── Линза (переключатель) ─────────────────────────

private fun lensRect(size: Size, count: Int, pos: Float, selected: Int, stretch: Float, inset: Float): Rect {
    val itemW = size.width / count
    val s = (abs(pos - selected) * 0.35f + stretch).coerceAtMost(0.6f)
    val w = itemW - inset * 2f + itemW * s
    val left = pos * itemW + inset - itemW * s / 2f
    return Rect(left, inset, left + w, size.height - inset)
}

@Composable
fun LiquidLens(
    count: Int,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 68.dp,
    content: @Composable (index: Int, accent: Boolean) -> Unit,
) {
    val g = LocalGlass.current
    val haptic = LocalHapticFeedback.current
    val hOn = LocalHapticsOn.current
    val scope = rememberCoroutineScope()
    val lens = remember { Animatable(selected.toFloat()) }
    val stretch = remember { Animatable(0f) }
    var widthPx by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    val currentSelected by rememberUpdatedState(selected)
    val insetPx = with(LocalDensity.current) { 5.dp.toPx() }
    val strokePx = with(LocalDensity.current) { 1.6.dp.toPx() }
    val shadowOff = with(LocalDensity.current) { 3.dp.toPx() }

    fun choose(i: Int) {
        if (i != currentSelected) {
            if (hOn) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onSelect(i)
        }
    }

    fun finishDrag() {
        dragging = false
        val t = lens.value.roundToInt().coerceIn(0, count - 1)
        choose(t)
        scope.launch { lens.animateTo(t.toFloat(), spring(dampingRatio = 0.55f, stiffness = 280f)) }
        scope.launch { stretch.animateTo(0f, spring(dampingRatio = 0.45f, stiffness = 260f)) }
    }

    LaunchedEffect(selected) {
        if (!dragging) lens.animateTo(selected.toFloat(), spring(dampingRatio = 0.6f, stiffness = 300f))
    }

    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .glass(RoundedCornerShape(percent = 50), elevation = 16.dp)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .drawBehind {
                val r = lensRect(size, count, lens.value, selected, stretch.value, insetPx)
                val radius = CornerRadius(r.height / 2f)
                drawRoundRect(
                    Color.Black.copy(alpha = 0.07f),
                    topLeft = Offset(r.left, r.top + shadowOff), size = r.size, cornerRadius = radius,
                )
                drawRoundRect(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = if (g.dark) 0.30f else 0.88f),
                            Color.White.copy(alpha = if (g.dark) 0.10f else 0.45f),
                        ),
                        startY = r.top, endY = r.bottom,
                    ),
                    topLeft = r.topLeft, size = r.size, cornerRadius = radius,
                )
                drawRoundRect(
                    g.accent.copy(alpha = 0.10f),
                    topLeft = r.topLeft, size = r.size, cornerRadius = radius,
                )
                drawRoundRect(
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.25f), Color.White.copy(alpha = 0.7f)),
                        start = r.topLeft, end = r.bottomRight,
                    ),
                    topLeft = r.topLeft, size = r.size, cornerRadius = radius,
                    style = Stroke(strokePx),
                )
            }
            .pointerInput(count) {
                detectHorizontalDragGestures(
                    onDragStart = {
                        dragging = true
                        scope.launch { lens.stop() }
                    },
                    onDragEnd = { finishDrag() },
                    onDragCancel = { finishDrag() },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        val itemW = widthPx / count
                        scope.launch {
                            lens.snapTo((lens.value + dx / itemW).coerceIn(-0.2f, count - 0.8f))
                            stretch.snapTo((abs(dx) / 18f).coerceAtMost(0.4f))
                        }
                    },
                )
            },
    ) {
        Row(Modifier.fillMaxSize()) {
            repeat(count) { i ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) { choose(i) },
                    contentAlignment = Alignment.Center,
                ) { content(i, false) }
            }
        }
        Row(
            Modifier
                .fillMaxSize()
                .drawWithContent {
                    val r = lensRect(size, count, lens.value, selected, stretch.value, insetPx)
                    val p = Path().apply { addRoundRect(RoundRect(r, CornerRadius(r.height / 2f))) }
                    clipPath(p) { this@drawWithContent.drawContent() }
                },
        ) {
            repeat(count) { i ->
                Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) { content(i, true) }
            }
        }
    }
}

@Composable
fun TabItemContent(icon: ImageVector, label: String, accent: Boolean) {
    val g = LocalGlass.current
    val c = if (accent) g.accent else g.dim
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, contentDescription = null, tint = c, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = c, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SegmentText(label: String, accent: Boolean) {
    val g = LocalGlass.current
    Text(
        label,
        color = if (accent) g.accent else g.dim,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
    )
}

// ───────────────────────── Переключатель ─────────────────────────

@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = LocalGlass.current
    val haptic = LocalHapticFeedback.current
    val hOn = LocalHapticsOn.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val pos by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 380f), label = "sw")
    val grow by animateFloatAsState(if (pressed) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "swg")
    val trackColor = lerp(g.track, g.good.copy(alpha = 0.85f), pos)
    val thumbW = (30f + 10f * grow).dp
    val x = (3f + pos * (58f - 30f - 10f * grow)).dp
    Box(
        Modifier
            .size(64.dp, 36.dp)
            .clip(CircleShape)
            .background(trackColor)
            .border(1.dp, g.rimDim, CircleShape)
            .clickable(interactionSource = src, indication = null) {
                if (hOn) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onChange(!checked)
            },
    ) {
        Box(
            Modifier
                .offset(x = x, y = 3.dp)
                .size(thumbW, 30.dp)
                .shadow(4.dp, CircleShape)
                .background(Color.White.copy(alpha = 0.96f), CircleShape),
        )
    }
}

// ───────────────────────── Слайдер ─────────────────────────

@Composable
fun GlassSlider(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    var widthPx by remember { mutableFloatStateOf(1f) }
    var active by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (active) 1f else 0f, spring(dampingRatio = 0.4f, stiffness = 420f), label = "slg")
    val density = LocalDensity.current
    Box(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(Unit) {
                detectTapGestures(onPress = { o ->
                    active = true
                    onChange((o.x / widthPx).coerceIn(0f, 1f))
                    tryAwaitRelease()
                    active = false
                })
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { active = true },
                    onDragEnd = { active = false },
                    onDragCancel = { active = false },
                ) { change, _ ->
                    change.consume()
                    onChange((change.position.x / widthPx).coerceIn(0f, 1f))
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height / 2f
            val th = 8.dp.toPx()
            drawRoundRect(
                g.track, topLeft = Offset(0f, cy - th / 2f), size = Size(size.width, th),
                cornerRadius = CornerRadius(th / 2f),
            )
            drawRoundRect(
                g.accent.copy(alpha = 0.85f), topLeft = Offset(0f, cy - th / 2f),
                size = Size(size.width * value, th), cornerRadius = CornerRadius(th / 2f),
            )
        }
        val thumbWDp = (34f + 16f * grow).dp
        val thumbHDp = (28f + 6f * grow).dp
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .offset {
                    val tw = with(density) { thumbWDp.toPx() }
                    IntOffset((value * (widthPx - tw)).roundToInt(), 0)
                }
                .size(thumbWDp, thumbHDp)
                .glass(CircleShape, elevation = 6.dp, strength = 2.2f),
        )
    }
}

// ───────────────────────── Кнопка питания ─────────────────────────

@Composable
fun PowerOrb(status: VpnStatus, onClick: () -> Unit) {
    val g = LocalGlass.current
    val connected = status == VpnStatus.Connected
    val busy = status == VpnStatus.Connecting || status == VpnStatus.Disconnecting
    val inf = rememberInfiniteTransition(label = "orb")
    val ring1 by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(2800, easing = LinearOutSlowInEasing)), label = "r1",
    )
    val ring2 by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2800, easing = LinearOutSlowInEasing), initialStartOffset = StartOffset(1400)),
        label = "r2",
    )
    val spin by inf.animateFloat(
        0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "spin",
    )
    val breathe by inf.animateFloat(
        0.985f, 1.03f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe",
    )
    val tint by animateColorAsState(
        when {
            connected -> g.good.copy(alpha = 0.30f)
            busy -> g.accent.copy(alpha = 0.22f)
            else -> Color.Transparent
        },
        tween(700), label = "tint",
    )
    val iconColor by animateColorAsState(
        when {
            connected -> g.goodStrong
            busy -> g.accent
            else -> g.dim
        },
        tween(500), label = "icon",
    )
    val scale by animateFloatAsState(
        if (connected) 1.05f else 1f, spring(dampingRatio = 0.4f, stiffness = 200f), label = "scale",
    )

    Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val maxR = size.minDimension / 2f
            if (connected) {
                listOf(ring1, ring2).forEach { p ->
                    drawCircle(
                        g.good.copy(alpha = 0.34f * (1f - p)),
                        radius = maxR * (0.74f + 0.26f * p),
                        style = Stroke(2.dp.toPx()),
                    )
                }
            }
            if (busy) {
                val r = 98.dp.toPx() + 14.dp.toPx()
                rotate(spin) {
                    drawArc(
                        brush = Brush.sweepGradient(listOf(Color.Transparent, g.accent)),
                        startAngle = 0f, sweepAngle = 270f, useCenter = false,
                        topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2, r * 2),
                        style = Stroke(5.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }
        }
        Box(
            Modifier
                .size(196.dp)
                .graphicsLayer {
                    val b = if (connected) breathe else 1f
                    scaleX = scale * b
                    scaleY = scale * b
                }
                .bounceClick(enabled = !busy, scaleTo = 0.9f, onClick = onClick)
                .glass(CircleShape, tint = tint, elevation = 22.dp, strength = 1.1f),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(76.dp)) {
                val sw = 7.dp.toPx()
                val r = size.minDimension / 2f - sw
                drawArc(
                    iconColor, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                    topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2, r * 2),
                    style = Stroke(sw, cap = StrokeCap.Round),
                )
                drawLine(
                    iconColor, Offset(center.x, center.y - r * 1.05f), Offset(center.x, center.y - r * 0.1f),
                    strokeWidth = sw, cap = StrokeCap.Round,
                )
            }
        }
    }
}
