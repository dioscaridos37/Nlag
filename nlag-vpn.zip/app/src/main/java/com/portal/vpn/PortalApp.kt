package com.portal.vpn

import android.app.Application

class PortalApp : Application() {
    lateinit var repo: ConfigRepository
    lateinit var prefs: Prefs
    lateinit var controller: VpnController

    override fun onCreate() {
        super.onCreate()
        repo = ConfigRepository(this)
        prefs = Prefs(this)
        controller = VpnController(this)
    }
}
