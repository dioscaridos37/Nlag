package com.portal.vpn

data class Profile(
    val id: String,
    val country: String?,
    val title: String,
    val subtitle: String,
    val endpoint: String,
    val text: String,
    val builtIn: Boolean,
)

object Countries {
    private val names = mapOf(
        "CA" to "Канада", "NO" to "Норвегия", "NL" to "Нидерланды", "PL" to "Польша",
        "CH" to "Швейцария", "US" to "США", "DE" to "Германия", "FR" to "Франция",
        "GB" to "Великобритания", "UK" to "Великобритания", "JP" to "Япония", "SE" to "Швеция",
        "FI" to "Финляндия", "ES" to "Испания", "IT" to "Италия", "SG" to "Сингапур",
        "AU" to "Австралия", "RO" to "Румыния", "UA" to "Украина", "TR" to "Турция",
        "CZ" to "Чехия", "AT" to "Австрия", "BR" to "Бразилия", "MX" to "Мексика",
        "HK" to "Гонконг", "KR" to "Корея", "IN" to "Индия", "LT" to "Литва", "LV" to "Латвия",
        "EE" to "Эстония", "DK" to "Дания", "BE" to "Бельгия", "IE" to "Ирландия",
        "PT" to "Португалия", "BG" to "Болгария", "HU" to "Венгрия", "RS" to "Сербия",
        "MD" to "Молдова", "KZ" to "Казахстан", "IL" to "Израиль", "AE" to "ОАЭ",
        "ZA" to "ЮАР", "IS" to "Исландия", "GR" to "Греция", "SK" to "Словакия",
    )

    fun name(code: String?): String = names[code] ?: code ?: "Свой сервер"

    fun flag(code: String?): String {
        if (code == null || code.length != 2) return "🌐"
        val c = code.uppercase().let { if (it == "UK") "GB" else it }
        if (c.any { it !in 'A'..'Z' }) return "🌐"
        val a = Character.toChars(0x1F1E6 + (c[0] - 'A'))
        val b = Character.toChars(0x1F1E6 + (c[1] - 'A'))
        return String(a) + String(b)
    }
}

object ConfigParser {
    private val endpointRe = Regex("""(?im)^\s*Endpoint\s*=\s*(.+?)\s*$""")
    private val serverRe = Regex("""(?im)^\s*#\s*Server:\s*(\S+)""")
    private val tagRe = Regex("""^([A-Z]{2})-\w+#(\d+)""")
    private val fileRe = Regex("""^(?:PORTAL-)?([A-Z]{2})[_\-](\d+)""")

    fun quickCheck(text: String): String? {
        val t = text.lowercase()
        if (!t.contains("[interface]") || !t.contains("[peer]") ||
            !t.contains("privatekey") || !t.contains("publickey") || !t.contains("endpoint")
        ) return "Это не похоже на конфиг WireGuard / AmneziaWG"
        return null
    }

    fun build(id: String, baseName: String, text: String, builtIn: Boolean): Profile {
        val endpoint = endpointRe.find(text)?.groupValues?.get(1) ?: "—"
        val tag = serverRe.find(text)?.groupValues?.get(1)
        val code = tag?.let { tagRe.find(it)?.groupValues?.get(1) }
            ?: fileRe.find(baseName)?.groupValues?.get(1)
        val title = if (code != null) Countries.name(code) else baseName
        val subtitle = listOfNotNull(tag, endpoint).joinToString(" · ")
        return Profile(id, code, title, subtitle, endpoint, text, builtIn)
    }
}
