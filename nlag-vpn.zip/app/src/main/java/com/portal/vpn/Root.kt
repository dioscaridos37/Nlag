package com.portal.vpn

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay

private fun readUri(ctx: Context, uri: Uri): Pair<String, String> {
    var name = "Конфиг"
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) name = c.getString(0) ?: name
    }
    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
    require(bytes.size < 200_000) { "Файл слишком большой" }
    return name.removeSuffix(".conf") to bytes.toString(Charsets.UTF_8)
}

@Composable
fun PortalRoot(app: PortalApp, activity: ComponentActivity, requestVpn: (() -> Unit) -> Unit) {
    val ctrl = app.controller
    val status by ctrl.status.collectAsState()
    val activeId by ctrl.activeId.collectAsState()
    val traffic by ctrl.traffic.collectAsState()
    val connectedAt by ctrl.connectedAt.collectAsState()

    var profiles by remember { mutableStateOf(app.repo.loadAll()) }
    var selectedId by remember { mutableStateOf(app.prefs.selectedId) }
    var tab by remember { mutableIntStateOf(0) }
    var theme by remember { mutableIntStateOf(app.prefs.theme) }
    var haptics by remember { mutableStateOf(app.prefs.haptics) }
    var glowV by remember { mutableFloatStateOf(app.prefs.glow) }
    var showAdd by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }

    val selected = profiles.firstOrNull { it.id == selectedId } ?: profiles.firstOrNull()
    val dark = when (theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val colors = if (dark) DarkGlass else LightGlass

    SideEffect {
        val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }

    LaunchedEffect(Unit) { ctrl.error.collect { if (it != null) toast = it } }
    LaunchedEffect(toast) {
        if (toast != null) {
            delay(3500)
            toast = null
        }
    }

    fun addProfile(name: String, text: String): String? {
        val err = ctrl.validate(text)
        if (err != null) return err
        val p = app.repo.add(name, text)
        profiles = app.repo.loadAll()
        selectedId = p.id
        app.prefs.selectedId = p.id
        return null
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        var ok = 0
        var lastErr: String? = null
        uris.forEach { uri ->
            try {
                val (n, t) = readUri(activity, uri)
                val e = addProfile(n, t)
                if (e == null) ok++ else lastErr = e
            } catch (e: Exception) {
                lastErr = e.message ?: "Не удалось прочитать файл"
            }
        }
        if (uris.isNotEmpty()) {
            toast = if (ok > 0) "Добавлено конфигов: $ok" else (lastErr ?: "Ничего не добавлено")
            if (ok > 0) showAdd = false
        }
    }

    fun toggle() {
        when (status) {
            VpnStatus.Disconnected -> selected?.let { p -> requestVpn { ctrl.connect(p) } }
            VpnStatus.Connected -> ctrl.disconnect()
            else -> {}
        }
    }

    fun select(p: Profile) {
        selectedId = p.id
        app.prefs.selectedId = p.id
        if (status == VpnStatus.Connected && activeId != p.id) ctrl.connect(p)
    }

    fun delete(p: Profile) {
        if (activeId == p.id) ctrl.disconnect()
        app.repo.delete(p)
        profiles = app.repo.loadAll()
        if (selectedId == p.id) {
            selectedId = profiles.firstOrNull()?.id
            app.prefs.selectedId = selectedId
        }
        toast = "Конфиг удалён"
    }

    CompositionLocalProvider(LocalGlass provides colors, LocalHapticsOn provides haptics) {
        MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
            Box(Modifier.fillMaxSize()) {
                AuroraBackground(
                    connected = status == VpnStatus.Connected,
                    glow = 0.2f + 0.8f * glowV,
                )

                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (slideInHorizontally(spring(dampingRatio = 0.75f, stiffness = 260f)) { dir * it / 3 } + fadeIn(tween(220))) togetherWith
                            (slideOutHorizontally(tween(220)) { -dir * it / 3 } + fadeOut(tween(160)))
                    },
                    label = "tabs",
                ) { t ->
                    when (t) {
                        0 -> HomeScreen(
                            status, selected, traffic, connectedAt,
                            onToggle = { toggle() }, onOpenServers = { tab = 1 },
                        )
                        1 -> ServersScreen(
                            profiles, selected?.id, status, activeId,
                            onSelect = { select(it) }, onDelete = { delete(it) }, onAdd = { showAdd = true },
                        )
                        else -> SettingsScreen(
                            theme, { theme = it; app.prefs.theme = it },
                            haptics, { haptics = it; app.prefs.haptics = it },
                            glowV, { glowV = it; app.prefs.glow = it },
                            profiles.count { it.builtIn },
                        )
                    }
                }

                LiquidLens(
                    count = 3, selected = tab, onSelect = { tab = it },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(start = 24.dp, end = 24.dp, bottom = 14.dp),
                ) { i, accent ->
                    when (i) {
                        0 -> TabItemContent(Icons.Rounded.Home, "Главная", accent)
                        1 -> TabItemContent(Icons.Rounded.Place, "Серверы", accent)
                        else -> TabItemContent(Icons.Rounded.Settings, "Настройки", accent)
                    }
                }

                if (showAdd) {
                    AddConfigDialog(
                        onDismiss = { showAdd = false },
                        onPickFiles = { picker.launch(arrayOf("*/*")) },
                        onSubmit = { n, t -> addProfile(n, t) },
                    )
                }

                AnimatedVisibility(
                    visible = toast != null,
                    modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 8.dp, start = 24.dp, end = 24.dp),
                    enter = slideInVertically(spring(dampingRatio = 0.55f, stiffness = 350f)) { -it * 2 } + fadeIn(),
                    exit = slideOutVertically(tween(200)) { -it * 2 } + fadeOut(),
                ) {
                    Box(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), elevation = 12.dp, strength = 2f).padding(16.dp),
                    ) {
                        Text(toast ?: "", color = colors.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
