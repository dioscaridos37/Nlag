package com.portal.vpn

import android.content.Context
import androidx.core.content.edit
import java.io.File

class ConfigRepository(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "custom").apply { mkdirs() }

    fun loadAll(): List<Profile> {
        val builtIn = (ctx.assets.list("configs") ?: emptyArray())
            .filter { it.endsWith(".conf") }
            .sorted()
            .map { name ->
                val base = name.removeSuffix(".conf")
                val text = ctx.assets.open("configs/$name").bufferedReader().use { it.readText() }
                ConfigParser.build("b_$base", base, text, true)
            }
        val custom = (dir.listFiles { f -> f.extension == "conf" } ?: emptyArray())
            .sortedBy { it.lastModified() }
            .map { f ->
                ConfigParser.build("c_${f.name}", f.nameWithoutExtension, f.readText(), false)
            }
        return builtIn + custom
    }

    fun add(name: String, text: String): Profile {
        val clean = name.replace(Regex("[^\\p{L}\\p{N} _.#-]"), "").trim().take(40).ifEmpty { "Конфиг" }
        var f = File(dir, "$clean.conf")
        var i = 2
        while (f.exists()) { f = File(dir, "$clean-$i.conf"); i++ }
        f.writeText(text.replace("\r\n", "\n").trim() + "\n")
        return ConfigParser.build("c_${f.name}", f.nameWithoutExtension, f.readText(), false)
    }

    fun delete(p: Profile) {
        if (p.builtIn) return
        File(dir, p.id.removePrefix("c_")).delete()
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("portal", Context.MODE_PRIVATE)

    var selectedId: String?
        get() = sp.getString("sel", null)
        set(v) = sp.edit { putString("sel", v) }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit { putInt("theme", v) }
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) = sp.edit { putBoolean("haptics", v) }
    var glow: Float
        get() = sp.getFloat("glow", 0.75f)
        set(v) = sp.edit { putFloat("glow", v) }
}
