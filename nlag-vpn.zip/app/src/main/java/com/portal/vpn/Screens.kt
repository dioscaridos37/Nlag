package com.portal.vpn

import android.content.ClipboardManager
import android.content.Context
import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale

// ───────────────────────── Форматирование ─────────────────────────

fun fmtBytes(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return if (i == 0) "$b B" else String.format(Locale.US, "%.1f %s", v, u[i])
}

fun fmtSpeed(b: Long) = fmtBytes(b) + "/s"

fun fmtTime(sec: Long): String =
    String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)

// ───────────────────────── Мелкие компоненты ─────────────────────────

@Composable
fun FlagBadge(code: String?, size: Dp) {
    Box(
        Modifier.size(size).glass(CircleShape, elevation = 4.dp, strength = 0.9f),
        contentAlignment = Alignment.Center,
    ) { Text(Countries.flag(code), fontSize = (size.value * 0.5f).sp) }
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, primary: Boolean = false, onClick: () -> Unit) {
    val g = LocalGlass.current
    Box(
        modifier
            .bounceClick(scaleTo = 0.93f, onClick = onClick)
            .glass(
                RoundedCornerShape(percent = 50),
                tint = if (primary) g.accent.copy(alpha = 0.28f) else Color.Transparent,
                elevation = 6.dp,
                strength = 1.3f,
            )
            .padding(horizontal = 20.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, color = if (primary) g.accent else g.text,
            fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun GlassField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    mono: Boolean = false,
) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .clip(shape)
            .background(g.track)
            .border(1.dp, g.rimDim, shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        if (value.isEmpty()) Text(hint, color = g.dim, fontSize = 14.sp)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = singleLine,
            textStyle = TextStyle(
                color = g.text,
                fontSize = if (mono) 12.sp else 15.sp,
                fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
            ),
            cursorBrush = SolidColor(g.accent),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String) {
    val g = LocalGlass.current
    Column {
        Text(title, color = g.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = g.dim, fontSize = 13.sp)
    }
}

@Composable
fun ServerChip(profile: Profile?, onClick: () -> Unit) {
    val g = LocalGlass.current
    Row(
        Modifier
            .fillMaxWidth()
            .bounceClick(scaleTo = 0.96f, onClick = onClick)
            .glass(RoundedCornerShape(26.dp), elevation = 8.dp)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FlagBadge(profile?.country, 46.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                profile?.title ?: "Нет серверов",
                color = g.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
            )
            Text(
                profile?.subtitle ?: "Добавьте свой конфиг во вкладке «Серверы»",
                color = g.dim, fontSize = 12.sp, maxLines = 1,
            )
        }
        Text("›", color = g.dim, fontSize = 28.sp)
    }
}

@Composable
fun StatCard(label: String, speed: String, total: String, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    Column(modifier.glass(RoundedCornerShape(24.dp), elevation = 8.dp).padding(16.dp)) {
        Text(label, color = g.dim, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Text(speed, color = g.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("всего $total", color = g.dim, fontSize = 12.sp)
    }
}

// ───────────────────────── Главный экран ─────────────────────────

@Composable
fun HomeScreen(
    status: VpnStatus,
    profile: Profile?,
    traffic: Traffic,
    connectedAt: Long,
    onToggle: () -> Unit,
    onOpenServers: () -> Unit,
) {
    val g = LocalGlass.current
    var elapsed by remember { mutableLongStateOf(0L) }
    LaunchedEffect(status, connectedAt) {
        if (status == VpnStatus.Connected) {
            while (true) {
                elapsed = (SystemClock.elapsedRealtime() - connectedAt) / 1000
                delay(500)
            }
        } else {
            elapsed = 0
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth()) { ScreenTitle("NLAG-VPN", "Быстрый и тихий VPN") }
        Spacer(Modifier.height(16.dp))
        ServerChip(profile, onOpenServers)
        Spacer(Modifier.weight(1f))
        PowerOrb(status, onToggle)
        Spacer(Modifier.height(6.dp))
        AnimatedContent(
            targetState = status,
            transitionSpec = {
                (fadeIn(tween(300)) + scaleIn(spring(0.6f, 400f), initialScale = 0.85f)) togetherWith fadeOut(tween(150))
            },
            label = "status",
        ) { s ->
            val (title, color) = when (s) {
                VpnStatus.Disconnected -> "Не подключено" to g.text
                VpnStatus.Connecting -> "Подключение…" to g.accent
                VpnStatus.Connected -> "Защищено" to g.goodStrong
                VpnStatus.Disconnecting -> "Отключение…" to g.dim
            }
            Text(title, color = color, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            if (status == VpnStatus.Connected) fmtTime(elapsed) else "Нажмите на кнопку",
            color = g.dim, fontSize = 15.sp, fontWeight = FontWeight.Medium,
        )
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Загрузка", fmtSpeed(traffic.rxSpeed), fmtBytes(traffic.rxTotal), Modifier.weight(1f))
            StatCard("Отдача", fmtSpeed(traffic.txSpeed), fmtBytes(traffic.txTotal), Modifier.weight(1f))
        }
        Spacer(Modifier.height(116.dp))
    }
}

// ───────────────────────── Серверы ─────────────────────────

@Composable
fun ServerCard(
    profile: Profile,
    selected: Boolean,
    live: Boolean,
    order: Int,
    onClick: () -> Unit,
    onDelete: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val g = LocalGlass.current
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(minOf(order, 8) * 45L)
        shown = true
    }
    val enter by animateFloatAsState(if (shown) 1f else 0f, spring(dampingRatio = 0.65f, stiffness = 300f), label = "enter")
    val check by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.45f, stiffness = 500f), label = "check")

    Row(
        modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = enter.coerceIn(0f, 1f)
                translationY = (1f - enter) * 70f
            }
            .bounceClick(scaleTo = 0.96f, onClick = onClick)
            .glass(
                RoundedCornerShape(26.dp),
                tint = if (selected) g.accent.copy(alpha = 0.13f) else Color.Transparent,
                elevation = 6.dp,
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FlagBadge(profile.country, 46.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(profile.title, color = g.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                if (live) {
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.size(8.dp).clip(CircleShape).background(g.good))
                }
            }
            Text(profile.subtitle, color = g.dim, fontSize = 12.sp, maxLines = 1)
        }
        if (onDelete != null) {
            Box(
                Modifier
                    .size(38.dp)
                    .bounceClick(scaleTo = 0.85f, onClick = onDelete)
                    .glass(CircleShape, elevation = 2.dp),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Delete, null, tint = g.bad, modifier = Modifier.size(20.dp)) }
            Spacer(Modifier.width(10.dp))
        }
        Box(
            Modifier
                .size(30.dp)
                .graphicsLayer { scaleX = check; scaleY = check }
                .clip(CircleShape)
                .background(g.accent),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(19.dp)) }
        if (check < 0.01f) Spacer(Modifier.width(0.dp))
    }
}

@Composable
fun ServersScreen(
    profiles: List<Profile>,
    selectedId: String?,
    status: VpnStatus,
    activeId: String?,
    onSelect: (Profile) -> Unit,
    onDelete: (Profile) -> Unit,
    onAdd: () -> Unit,
) {
    val g = LocalGlass.current
    val builtIn = profiles.filter { it.builtIn }
    val custom = profiles.filter { !it.builtIn }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 150.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { ScreenTitle("Серверы", "${builtIn.size} готовых · ${custom.size} своих") }
            item { Text("Готовые", color = g.dim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp, start = 4.dp)) }
            items(builtIn, key = { it.id }) { p ->
                ServerCard(
                    p, p.id == selectedId, status == VpnStatus.Connected && activeId == p.id,
                    builtIn.indexOf(p), { onSelect(p) }, null,
                )
            }
            item { Text("Свои", color = g.dim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp, start = 4.dp)) }
            if (custom.isEmpty()) {
                item {
                    Text(
                        "Нажмите «+», чтобы добавить свой .conf (WireGuard / AmneziaWG).",
                        color = g.dim, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp),
                    )
                }
            }
            items(custom, key = { it.id }) { p ->
                ServerCard(
                    p, p.id == selectedId, status == VpnStatus.Connected && activeId == p.id,
                    custom.indexOf(p), { onSelect(p) }, { onDelete(p) },
                )
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 24.dp, bottom = 108.dp)
                .size(60.dp)
                .bounceClick(scaleTo = 0.82f, onClick = onAdd)
                .glass(CircleShape, tint = g.accent.copy(alpha = 0.30f), elevation = 14.dp, strength = 1.4f),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Add, null, tint = g.accent, modifier = Modifier.size(30.dp)) }
    }
}

// ───────────────────────── Настройки ─────────────────────────

@Composable
fun SettingsScreen(
    theme: Int,
    onTheme: (Int) -> Unit,
    haptics: Boolean,
    onHaptics: (Boolean) -> Unit,
    glowValue: Float,
    onGlow: (Float) -> Unit,
    builtInCount: Int,
) {
    val g = LocalGlass.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(4.dp))
        ScreenTitle("Настройки", "Внешний вид и поведение")

        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), elevation = 8.dp).padding(18.dp)) {
            Text("Тема", color = g.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            val names = listOf("Авто", "Светлая", "Тёмная")
            LiquidLens(count = 3, selected = theme, onSelect = onTheme, height = 52.dp) { i, accent ->
                SegmentText(names[i], accent)
            }
        }

        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), elevation = 8.dp).padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Вибрация", color = g.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Лёгкий отклик на нажатия", color = g.dim, fontSize = 12.sp)
            }
            GlassSwitch(haptics, onHaptics)
        }

        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), elevation = 8.dp).padding(18.dp)) {
            Text("Яркость фона", color = g.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            GlassSlider(glowValue, onGlow)
        }

        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), elevation = 8.dp).padding(18.dp)) {
            Text("О приложении", color = g.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                "NLAG-VPN 1.0 · AmneziaWG\nВстроено серверов: $builtInCount. Свои конфиги хранятся только на этом устройстве.",
                color = g.dim, fontSize = 13.sp, lineHeight = 18.sp,
            )
        }
        Spacer(Modifier.height(130.dp))
    }
}

// ───────────────────────── Диалог добавления ─────────────────────────

@Composable
fun AddConfigDialog(
    onDismiss: () -> Unit,
    onPickFiles: () -> Unit,
    onSubmit: (name: String, text: String) -> String?,
) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val sc by animateFloatAsState(if (shown) 1f else 0.82f, spring(dampingRatio = 0.55f, stiffness = 380f), label = "dlg")
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(220), label = "dlga")

    Box(
        Modifier
            .fillMaxSize()
            .background(g.scrim.copy(alpha = g.scrim.alpha * a))
            .pointerInput(Unit) { detectTapGestures { onDismiss() } }
            .imePadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(22.dp)
                .fillMaxWidth()
                .graphicsLayer { scaleX = sc; scaleY = sc; alpha = a }
                .glass(RoundedCornerShape(32.dp), elevation = 24.dp, strength = 1.8f)
                .pointerInput(Unit) { detectTapGestures { } }
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Добавить конфиг", color = g.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton("Из файла", Modifier.weight(1f)) { onPickFiles() }
                GlassButton("Из буфера", Modifier.weight(1f)) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
                    if (clip.isNullOrBlank()) error = "Буфер обмена пуст" else { text = clip; error = null }
                }
            }
            GlassField(name, { name = it }, "Название (необязательно)")
            GlassField(
                text, { text = it; error = null }, "Вставьте содержимое .conf",
                modifier = Modifier.height(170.dp), singleLine = false, mono = true,
            )
            if (error != null) Text(error!!, color = g.bad, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton("Отмена", Modifier.weight(1f)) { onDismiss() }
                GlassButton("Добавить", Modifier.weight(1f), primary = true) {
                    val err = onSubmit(name.ifBlank { "Конфиг" }, text)
                    if (err == null) onDismiss() else error = err
                }
            }
        }
    }
}
