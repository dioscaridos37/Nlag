package com.portal.vpn

import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private var pending: (() -> Unit)? = null

    private val vpnLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val cb = pending
            pending = null
            if (res.resultCode == RESULT_OK) cb?.invoke()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val app = application as PortalApp
        setContent { PortalRoot(app, this, ::requestVpn) }
    }

    private fun requestVpn(onGranted: () -> Unit) {
        val intent = VpnService.prepare(this)
        if (intent == null) {
            onGranted()
        } else {
            pending = onGranted
            vpnLauncher.launch(intent)
        }
    }
}
