package com.portal.vpn

import android.app.Application
import android.net.TrafficStats
import android.os.Process
import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.amnezia.awg.backend.GoBackend
import org.amnezia.awg.backend.Tunnel
import org.amnezia.awg.config.Config
import java.io.ByteArrayInputStream

enum class VpnStatus { Disconnected, Connecting, Connected, Disconnecting }

data class Traffic(val rxSpeed: Long = 0, val txSpeed: Long = 0, val rxTotal: Long = 0, val txTotal: Long = 0)

class VpnController(private val app: Application) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mutex = Mutex()
    private val backend by lazy { GoBackend(app) }

    private val _status = MutableStateFlow(VpnStatus.Disconnected)
    val status: StateFlow<VpnStatus> = _status
    private val _activeId = MutableStateFlow<String?>(null)
    val activeId: StateFlow<String?> = _activeId
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _connectedAt = MutableStateFlow(0L)
    val connectedAt: StateFlow<Long> = _connectedAt
    private val _traffic = MutableStateFlow(Traffic())
    val traffic: StateFlow<Traffic> = _traffic

    private var monitor: Job? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "portal"
        override fun onStateChange(newState: Tunnel.State) {
            // система/другое VPN-приложение могло отключить туннель
            if (newState == Tunnel.State.DOWN && _status.value == VpnStatus.Connected) {
                monitor?.cancel()
                _traffic.value = Traffic()
                _activeId.value = null
                _status.value = VpnStatus.Disconnected
            }
        }
    }

    fun connect(profile: Profile) {
        scope.launch {
            mutex.withLock {
                try {
                    if (_status.value == VpnStatus.Connected) {
                        monitor?.cancel()
                        withContext(Dispatchers.IO) { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                    }
                    _status.value = VpnStatus.Connecting
                    _error.value = null
                    _traffic.value = Traffic()
                    withContext(Dispatchers.IO) { bringUp(profile.text) }
                    _activeId.value = profile.id
                    _connectedAt.value = SystemClock.elapsedRealtime()
                    _status.value = VpnStatus.Connected
                    startMonitor()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    _activeId.value = null
                    _status.value = VpnStatus.Disconnected
                    _error.value = friendly(e)
                }
            }
        }
    }

    fun disconnect() {
        scope.launch {
            mutex.withLock {
                if (_status.value == VpnStatus.Disconnected) return@withLock
                _status.value = VpnStatus.Disconnecting
                monitor?.cancel()
                try {
                    withContext(Dispatchers.IO) { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                }
                _traffic.value = Traffic()
                _activeId.value = null
                _status.value = VpnStatus.Disconnected
            }
        }
    }

    fun validate(text: String): String? {
        ConfigParser.quickCheck(text)?.let { return it }
        return try {
            parse(text)
            null
        } catch (e: Throwable) {
            friendly(e)
        }
    }

    // ---- internals ----

    private val extendedKeys = setOf("s3", "s4", "i1", "i2", "i3", "i4", "i5", "j1", "j2", "j3", "itime")

    private fun stripExtended(text: String): String =
        text.lineSequence().filterNot { line ->
            '=' in line && line.substringBefore('=').trim().lowercase() in extendedKeys
        }.joinToString("\n")

    private fun parse(text: String): Config {
        var last: Throwable? = null
        for (variant in listOf(text, stripExtended(text)).distinct()) {
            try {
                return Config.parse(ByteArrayInputStream(variant.toByteArray()))
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Не удалось разобрать конфиг")
    }

    // Пробуем полный конфиг (AWG 2.0); если библиотека не знает новых полей — без них
    private fun bringUp(text: String) {
        var last: Throwable? = null
        for (variant in listOf(text, stripExtended(text)).distinct()) {
            try {
                val cfg = Config.parse(ByteArrayInputStream(variant.toByteArray()))
                backend.setState(tunnel, Tunnel.State.UP, cfg)
                return
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Не удалось запустить туннель")
    }

    private fun startMonitor() {
        monitor?.cancel()
        monitor = scope.launch(Dispatchers.Default) {
            val uid = Process.myUid()
            fun rx() = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
            fun tx() = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
            val rx0 = rx()
            val tx0 = tx()
            var lastRx = rx0
            var lastTx = tx0
            while (isActive) {
                delay(1000)
                val r = rx()
                val t = tx()
                _traffic.value = Traffic(r - lastRx, t - lastTx, r - rx0, t - tx0)
                lastRx = r
                lastTx = t
            }
        }
    }

    private fun friendly(e: Throwable): String {
        val m = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
        return m.take(160)
    }
}
